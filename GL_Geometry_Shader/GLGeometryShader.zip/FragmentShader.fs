#version 330 core

in vec4 fColor;
// Ouput data
out vec4 color;


void main() { 
	color = fColor;
}